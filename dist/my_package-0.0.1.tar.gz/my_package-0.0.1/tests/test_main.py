# test_script.py

from my_package import main

def test_main():
    result = main.main_function()
    assert result == "Hello, World!", f"Beklenen 'Hello, World!', ancak aldığımız: {result}"

if __name__ == "__main__":
    test_main()
    print("Test başarılı!")
