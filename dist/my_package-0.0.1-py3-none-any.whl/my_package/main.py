# src/my_package/main.py

def main_function():
    return "Hello, World!"
