from my_package import main

print(main.main_function())
